package EinesControl.Classes;

public class Pacient extends Persona {
    String malaltia;
}
