package EinesControl;

public class Temp {

    public static void main(String[] args) {
       System.out.println(Factorial.calculFactorial(5));
    }


}
