public class Enu11_For_0_100 {
    /*
     * Fer un programa en Java que mostri els nombres del 0 al 100. Només es pot fer
     * servir, la sentencia for.
     */
    public static void main(String[] args) {

        for (int i = 0; i <= 100; i = i + 1) {
            System.out.println(i);
        }
    }
}