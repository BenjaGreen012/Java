package Fitxers;

public class Contacte {
    public String nom = "";
    public String cognom = "";
    public String telefon = "";
    public String correu = "";
    public String adresa = "";

    // // public String() {
    // //     this.value = "".value;
    // //     this.coder = "".coder;
    // // }

    Contacte() {
        this.nom = "";
        this.cognom = "";
        this.telefon = "";
        this.correu = "";
        this.adresa = "";
    }

    // Contacte(String nom, String cognom, String telefon, String correu, String adresa) {
    //     this.nom = nom;
    //     this.cognom = cognom;
    //     this.telefon = telefon;
    //     this.correu = correu;
    //     this.adresa = adresa;
    // }

}
